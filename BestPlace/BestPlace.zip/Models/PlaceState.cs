﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BestPlace.Models
{
    public enum PlaceState
    {
        Waitting = 0,
        Actived = 1,
        Denied = 2
    }
}